﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

public partial class Admin_Dashboard : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        objmysqlcommand.CommandText = "select count(*) as count from tbl_customer";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            countcustomer.InnerText = objdatatable.Rows[0]["count"].ToString();
        }
        objmysqlcommand.CommandText = "select count(*) as count from tbl_district";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            H1.InnerText = objdatatable.Rows[0]["count"].ToString();
        }
        //objmysqlcommand.CommandText = "select count(*) as count from tbl_location";
        //objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        //if (objdatatable.Rows.Count > 0)
        //{
        //    H2.InnerText = objdatatable.Rows[0]["count"].ToString();
        //}
        objmysqlcommand.CommandText = "select count(*) as count from tbl_Connection";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            H3.InnerText = objdatatable.Rows[0]["count"].ToString();
        }
        objmysqlcommand.CommandText = "select count(*) as count from tbl_engineer";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            H4.InnerText = objdatatable.Rows[0]["count"].ToString();
        }
        objmysqlcommand.CommandText = "select count(*) as count from tbl_complaint";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            H5.InnerText = objdatatable.Rows[0]["count"].ToString();
        }
        objmysqlcommand.CommandText = "select count(*) as count from tbl_office";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            H6.InnerText = objdatatable.Rows[0]["count"].ToString();
        }
        objmysqlcommand.CommandText = "select count(*) as count from tbl_application Where Status='ACCEPTED'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            H7.InnerText = objdatatable.Rows[0]["count"].ToString();
        }
        objmysqlcommand.CommandText = "select count(*) as count from tbl_application Where Status='REJECTED'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            H2.InnerText = objdatatable.Rows[0]["count"].ToString();
        }
        //objmysqlcommand.CommandText = "select count(*) as count from tbl_employee";
        //objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        //if (objdatatable.Rows.Count > 0)
        //{
        //    H9.InnerText = objdatatable.Rows[0]["count"].ToString();
        //}
        //objmysqlcommand.CommandText = "select count(*) as count from tbl_facilities";
        //objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        //if (objdatatable.Rows.Count > 0)
        //{
        //    H10.InnerText = objdatatable.Rows[0]["count"].ToString();
        //}
        //objmysqlcommand.CommandText = "select count(*) as count from tbl_packagemaster";
        //objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        //if (objdatatable.Rows.Count > 0)
        //{
        //    H11.InnerText = objdatatable.Rows[0]["count"].ToString();
        //}
    }
}