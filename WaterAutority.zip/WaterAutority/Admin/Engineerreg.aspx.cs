﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Net;


public partial class Admin_Engineerreg : System.Web.UI.Page
{

    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int engineer_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        engineer_id = Convert.ToInt32(Request.QueryString["cid"]);
        
        if (!IsPostBack)
        {
            Filldistrictdropdown();
            Filldata();
        }
    }
    public bool insertdata()
    {

        string ranPass = RandomString(10);
        objmysqlcommand.CommandText = "insert into tbl_engineer(EDId,ELId,EngineerName,EOId,EngineerPhone,EngineerEmail,EngPassword) " +
                                          "values('" + ddldistrict.SelectedValue + "','" + ddllocation.SelectedValue + "','" + txtname.Text + "','" + ddlofficename.SelectedValue + "','"
                                          + txtphonenumber.Text + "','" + txtemail.Text + "','" + ranPass + "')";
        SendPasswordEmail(toEmail: txtemail.Text, userPass: ranPass, name: txtname.Text.ToString());

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
           
            Response.Write("<script>alert('Engineer details successfully Saved');window.location='viewengineer.aspx'</script>");
        }

        return true;

    }
    private void SendPasswordEmail(string userPass, string toEmail, string name)
    {
        //try
        //{

        using (MailMessage mm = new MailMessage("projectrecoverymail@gmail.com", toEmail))
        {
            mm.Subject = "Water Authority";
            mm.Body = fnEmailBody(userPass, name);
            mm.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential("projectrecoverymail@gmail.com", "recoverymai");
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;
            smtp.Send(mm);
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Email sent.');", true);

        }
        //}
        //catch (Exception e)
        //{
        //    Response.Write("<script>alert('Customer details added..please check your email for login credentials!!not sent email');window.location='GuestHome.aspx'</script>");

        //}
    }
    private string fnEmailBody(string userPass, string name)
    {
        try
        {
            string emailBody = string.Empty;

            emailBody = string.Concat(emailBody, "<html> <h2> Password Authentication </h2> <body>");
            emailBody = string.Concat(emailBody, "Hello <b> ", name, "</b> congratulations !!! <br/> <br/>");
            emailBody = string.Concat(emailBody, "It's our pleasure to inform you that your registration process has been Completed .<br/> <br/>");
            emailBody = string.Concat(emailBody, "We request you to keep the Password attached with this mail for completing your registration and further proccedings and references.<br/> <br/>");
            emailBody = string.Concat(emailBody, "Username: <h4>", txtname.Text, "</h4><br/> <br/>");
            emailBody = string.Concat(emailBody, "Password: <h4>", userPass, "</h4><br/> <br/>");
            emailBody = string.Concat(emailBody, "Thank You");

            return emailBody;
        }
        catch
        {

            return null;
        }
    }
    private Random random = new Random();
    public string RandomString(int length)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        return new string(Enumerable.Repeat(chars, length)
          .Select(s => s[random.Next(s.Length)]).ToArray());
    }
   

    private Boolean Filldistrictdropdown()
    {
        objmysqlcommand.CommandText = "select * from tbl_district";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddldistrict.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddldistrict.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddldistrict.Items.Add(new ListItem(category["DistrictName"].ToString(), category["DistrictId"].ToString()));
            }
        }
        return true;
    }

    //private Boolean Fillofficedropdown()
    //{
    //    objmysqlcommand.CommandText = "SELECT * FROM tbl_office ";
    //    objdatatable = objdataaccess.GetRecords(objmysqlcommand);
    //    if (objdatatable.Rows.Count > 0)
    //    {
    //        ddlofficename.Items.Insert(0, "--SELECT--");
    //        foreach (DataRow dr in objdatatable.Rows)
    //        {
    //            ddlofficename.Items.Add(new ListItem(dr["name"].ToString(), dr["office_id"].ToString()));
    //        }
    //    }
    //    return true;
    //}
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_engineer where EngineerId=" + engineer_id;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            ddldistrict.SelectedValue = objdatatable.Rows[0]["EDId"].ToString();
            ddllocation.SelectedValue = objdatatable.Rows[0]["ELId"].ToString();
            ddlofficename.SelectedValue = objdatatable.Rows[0]["EOId"].ToString();
            txtname.Text = objdatatable.Rows[0]["EngineerName"].ToString();
            txtphonenumber.Text = objdatatable.Rows[0]["EngineerPhone"].ToString();
            txtemail.Text = objdatatable.Rows[0]["EngineerEmail"].ToString();
            //txtpasswd.Text = objdatatable.Rows[0]["EngPassword"].ToString();
        }
        return true;
    }
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_engineer SET EngineerName ='" + txtname.Text + "',EngineerPhone='" + txtphonenumber.Text + "',EngineerEmail ='" + txtemail.Text + "' where EngineerId='" + engineer_id + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Engineer details successfully Updated');window.location='viewengineer.aspx'</script>");

        }
        return true;
    }
    private Boolean checkAlreadyExist()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_engineer where EngineerEmail='" + txtemail.Text + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            Response.Write("<script>alert('Email is already exist ');window.location='viewengineer.aspx'</script>");
            return false;
        }
        return true;

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {

        if (Convert.ToInt32(engineer_id) > 0)
        {
            FnUpdateData();
        }
        else
        {
            if (checkAlreadyExist())
            {
                insertdata();
            }
        }
    }
    public void filllocation()
    {

        objmysqlcommand.CommandText = "select * from tbl_location where DId='" + ddldistrict.SelectedValue + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddllocation.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddllocation.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddllocation.Items.Add(new ListItem(category["LocationName"].ToString(), category["LocationId"].ToString()));
            }
        }
    }
    public void filloffice()
    {

        objmysqlcommand.CommandText = "select * from tbl_office where OLId='" + ddllocation.SelectedValue + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddlofficename.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddlofficename.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddlofficename.Items.Add(new ListItem(category["OfficeName"].ToString(), category["OfficeId"].ToString()));
            }
        }
    }
    protected void ddldistrict_SelectedIndexChanged(object sender, EventArgs e)
    {
        filllocation();
    }

    protected void ddllocation_SelectedIndexChanged(object sender, EventArgs e)
    {
        filloffice();
    }
}