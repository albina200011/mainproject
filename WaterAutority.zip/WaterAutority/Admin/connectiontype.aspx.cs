﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_connectiontype : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int typeid;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        typeid = Convert.ToInt32(Request.QueryString["cid"]);
        if (!IsPostBack)
        {
            Filldata();
        }
    }
    public bool insertdata()
    {
        objmysqlcommand.CommandText = "insert into tbl_connection(type) " +
                                         "values('" + txttypename.Text + "')";
        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Connection type details successfully Saved');window.location='viewconnection.aspx'</script>");
        }

        return true;

    }
   
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_connection SET type ='" + txttypename.Text + "'  where TypeId='" + typeid + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('connection type  details successfully Updated');window.location='viewconnection.aspx'</script>");
        }
        return true;
    }
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_connection where TypeId=" + typeid;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txttypename.Text = objdatatable.Rows[0]["type"].ToString();

        }
        return true;
    }


    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(typeid) > 0)
        {
            FnUpdateData();
        }
        else
        {
            insertdata();
            //if (checkAlreadyExist())
            {

            }
        }
    }
    protected void Btncancel_Click(object sender, EventArgs e)
    {
        txttypename.Text = "";
    }
}

    