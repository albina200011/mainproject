﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_frmviewlocation : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Filldistrictdropdown();
        }

    }
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int district_id = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "edt")
        {
            Response.Redirect("location.aspx?cid=" + district_id);
        }
        else
        {
            objmysqlcommand.CommandText = "delete from tbl_location where LocationId='" + district_id + "'";
            objdataaccess.ExecuteQuery(objmysqlcommand);
            Response.Write("<script>alert('Deleted Successfully');window.locationmanager='frmviewLocation.aspx'</script>");
            FillList();
        }
    }
    private Boolean Filldistrictdropdown()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_district  ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtdistrict.Items.Insert(0, "--SELECT--");
            foreach (DataRow dr in objdatatable.Rows)
            {
                txtdistrict.Items.Add(new ListItem(dr["DistrictName"].ToString(), dr["DistrictId"].ToString()));
            }
        }
        return true;
    }
    private Boolean FillList()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_location  where DId='" + txtdistrict.SelectedValue + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }

    protected void Btnaddnew_Click(object sender, EventArgs e)
    {
        Response.Redirect("location.aspx");
    }
    protected void txtdistrict_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillList();
    }
}