﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;

public partial class Admin_genderratio : System.Web.UI.Page
{

    DataAccess objDataAccess = new DataAccess();
    MySqlCommand objMySqlCommand = new MySqlCommand();
    DataTable objDataTable = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        FillChart();
    }
    private Boolean FillChart()
    {
        DataSet ds = new DataSet();

        objMySqlCommand.CommandText = "select Gender,count(*) as 'count' from tbl_customer group by Gender";
        objDataTable = objDataAccess.GetRecords(objMySqlCommand);
        string[] x = new string[objDataTable.Rows.Count];
        int[] y = new int[objDataTable.Rows.Count];
        for (int i = 0; i < objDataTable.Rows.Count; i++)
        {
            x[i] = objDataTable.Rows[i]["Gender"].ToString();
            y[i] = Convert.ToInt32(objDataTable.Rows[i]["count"]);
        }
        ratiochart.Series[0].Points.DataBindXY(x, y);
        ratiochart.Series[0].ChartType = SeriesChartType.Pie;

        foreach (Series charts in ratiochart.Series)
        {
            foreach (DataPoint point in charts.Points)
            {
                switch (point.AxisLabel)
                {
                    case "Male": point.Color = Color.RoyalBlue; break;
                    case "Female": point.Color = Color.SaddleBrown; break;
                }
                point.Label = string.Format("{0:0} - {1}", point.YValues[0], point.AxisLabel);

            }
        }
        return true;
    }
}