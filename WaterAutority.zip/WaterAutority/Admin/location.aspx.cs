﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_location : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int loc_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        loc_id = Convert.ToInt32(Request.QueryString["cid"]);
        if (!IsPostBack)
        {
            Filldistrictdropdown();
            Filldata();
        }
    }
    public bool insertdata()
    {
        objmysqlcommand.CommandText = "insert into tbl_location(LocationName,DId) " +
                                          "values('" + txtlocation.Text + "','" + txtdistrict.Text + "')";
        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Location details successfully Saved');window.location='frmViewLocation.aspx'</script>");
        }

        return true;

    }
    private Boolean Filldistrictdropdown()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_district ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtdistrict.Items.Insert(0, "--SELECT--");
            foreach (DataRow dr in objdatatable.Rows)
            {
                txtdistrict.Items.Add(new ListItem(dr["DistrictName"].ToString(), dr["DistrictId"].ToString()));
            }
        }
        return true;
    }
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_district,tbl_location where LocationId=" + loc_id;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtlocation.Text = objdatatable.Rows[0]["LocationName"].ToString();
            txtdistrict.SelectedValue = objdatatable.Rows[0]["DId"].ToString();
        }
        return true;
    }
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_location SET DId ='" + txtdistrict.Text + "',LocationName='" + txtlocation.Text + "' where LocationId='" + loc_id + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Location  details successfully Updated');window.location='frmViewLocation.aspx'</script>");

        }
        return true;
    }
    private Boolean checkAlreadyExist()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_location where LocationName='" + txtlocation.Text + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            Response.Write("<script>alert('Location is already exist ');window.location='frmViewLocation.aspx'</script>");
            return false;
        }
        return true;

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(loc_id) > 0)
        {
            FnUpdateData();
        }
        else
        {
            if (checkAlreadyExist())
            {
                insertdata();
            }
        }
    }
}