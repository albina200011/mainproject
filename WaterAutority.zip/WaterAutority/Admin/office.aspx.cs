﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_office : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int office_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        office_id = Convert.ToInt32(Request.QueryString["cid"]);
        if (!IsPostBack)
        {
            Filldistrictdropdown();
            
            Filldata();
        }
    }
    public bool insertdata()
    {
        objmysqlcommand.CommandText = "insert into tbl_office(ODId,OLId,OfficeName,LandMark,OfficeAddress,OfficePhone,OfficeEmail) " +
                                          "values('" + txtcategory.Text + "','" + txtsub.Text + "','" + txtplant.Text + "','" + txtwidth.Text + "','" + txtheight.Text + "','"
                                          + txtphn.Text + "','" +txtemail.Text +"')";
       
        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Office  details successfully Saved');window.location='viewoffice.aspx'</script>");
        }

        return true;

    }

    private Boolean Filldistrictdropdown()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_district ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtcategory.Items.Insert(0, "--SELECT--");
            foreach (DataRow dr in objdatatable.Rows)
            {
                txtcategory.Items.Add(new ListItem(dr["DistrictName"].ToString(), dr["DistrictId"].ToString()));
            }
        }
        return true;
    }
    private Boolean Filllocationdropdown()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_location where DId='"+txtcategory.SelectedValue+"' ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        txtsub.Items.Clear();
        if (objdatatable.Rows.Count > 0)
        {
            txtsub.Items.Insert(0, "--SELECT--");
            foreach (DataRow dr in objdatatable.Rows)
            {
                txtsub.Items.Add(new ListItem(dr["LocationName"].ToString(), dr["LocationId"].ToString()));
            }
        }
        return true;
    }
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_office where OfficeId=" + office_id;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtcategory.Text = objdatatable.Rows[0]["ODId"].ToString();
            txtsub.Text = objdatatable.Rows[0]["OLId"].ToString();
            txtplant.Text = objdatatable.Rows[0]["OfficeName"].ToString();
            txtwidth.Text = objdatatable.Rows[0]["LandMark"].ToString();
            txtheight.Text = objdatatable.Rows[0]["OfficeAddress"].ToString();
            txtphn.Text = objdatatable.Rows[0]["OfficePhone"].ToString();
            txtemail.Text = objdatatable.Rows[0]["OfficeEmail"].ToString();
        }
        return true;
    }
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_office SET OfficeName ='" + txtplant.Text + "',LandMark='" + txtwidth.Text + "',OfficeAddress='" + txtheight.Text + "',OfficePhone='" + txtphn.Text + "',OfficeEmail ='" + txtemail.Text + "' where OfficeId='" + office_id + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Office  details successfully Updated');window.location='viewoffice.aspx'</script>");

        }
        return true;
    }
    private Boolean checkAlreadyExist()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_office where OfficeEmail='" + txtemail.Text + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            Response.Write("<script>alert('Email is already exist ');window.location='viewoffice.aspx'</script>");
            return false;
        }
        return true;

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {

        if (Convert.ToInt32(office_id) > 0)
        {
            FnUpdateData();
        }
        else
        {
            if (checkAlreadyExist())
            {
                insertdata();
            }
        }
    }
    protected void txtcategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        Filllocationdropdown();
    }
}