﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;

public partial class Admin_piechart : System.Web.UI.Page
{
    DataAccess objDataAccess = new DataAccess();
    MySqlCommand objMySqlCommand = new MySqlCommand();
    DataTable objDataTable = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        FillChart();
    }
    private Boolean FillChart()
    {
        DataSet ds = new DataSet();

        objMySqlCommand.CommandText = "select count(*) as count,Type from tbl_connection t , tbl_application a where t.TypeId=a.ATypeId Group by t.Type ";
        objDataTable = objDataAccess.GetRecords(objMySqlCommand);
        string[] x = new string[objDataTable.Rows.Count];
        int[] y = new int[objDataTable.Rows.Count];
        for (int i = 0; i < objDataTable.Rows.Count; i++)
        {
            x[i] = objDataTable.Rows[i]["Type"].ToString();
            y[i] = Convert.ToInt32(objDataTable.Rows[i]["count"]);
        }
        ratiochart.Series[0].Points.DataBindXY(x, y);
        ratiochart.Series[0].ChartType = SeriesChartType.Pie;

        foreach (Series charts in ratiochart.Series)
        {
            foreach (DataPoint point in charts.Points)
            {
                switch (point.AxisLabel)
                {
                    case "domestic": point.Color = Color.RoyalBlue; break;
                    case "non domestic ": point.Color = Color.SaddleBrown; break;
                }
                point.Label = string.Format("{0:0} - {1}", point.YValues[0], point.AxisLabel);

            }
        }
        return true;
    }
}