﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_tariff : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int tarrif_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        tarrif_id = Convert.ToInt32(Request.QueryString["cid"]);
        if (!IsPostBack)
        {
            Fillcategorydropdown();
            Filldata();
        }
    }
    public bool insertdata()
    {
        objmysqlcommand.CommandText = "insert into tbl_tariff(TTId,Minimum_Quality,Amount,Addition) " +
                                          "values('" + txtcategory.Text + "','" + txtplant.Text + "','" + txtwidth.Text + "','" + txtheight.Text + "')";
        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Tariff details successfully Saved');window.location='Viewtariff.aspx'</script>");
        }

        return true;

    }

    private Boolean Fillcategorydropdown()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_connection ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtcategory.Items.Insert(0, "--SELECT--");
            foreach (DataRow dr in objdatatable.Rows)
            {
                txtcategory.Items.Add(new ListItem(dr["type"].ToString(), dr["TypeId"].ToString()));
            }
        }
        return true;
    }
   
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_tariff where Tariff_Id=" + tarrif_id;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtcategory.Text = objdatatable.Rows[0]["TTId"].ToString();
            txtplant.Text = objdatatable.Rows[0]["Minimum_Quality"].ToString();
            txtwidth.Text = objdatatable.Rows[0]["Amount"].ToString();
            txtheight.Text = objdatatable.Rows[0]["Addition"].ToString();
        }
        return true;
    }
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_tariff SET Minimum_Quality ='" + txtplant.Text + "',Amount='" + txtwidth.Text + "',Addition='" + txtheight.Text + "' where Tariff_Id='" + tarrif_id + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Tariff  details successfully Updated');window.location='Viewtariff.aspx'</script>");

        }
        return true;
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {

        if (Convert.ToInt32(tarrif_id) > 0)
        {
            FnUpdateData();
        }
        else
        {
                insertdata();
            //check already exists
            }
        }
    }
