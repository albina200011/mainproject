﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class guest_frmViewCustomer : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        FillList();

    }
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int typeid = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "edt")
        {
            Response.Redirect("connectiontype.aspx?cid=" + typeid);
        }
        else
        {
            objmysqlcommand.CommandText = "delete from tbl_connection where TypeId='" + typeid + "'";
            objdataaccess.ExecuteQuery(objmysqlcommand);
            Response.Write("<script>alert('Deleted Successfully');window.locationmanager='viewconnection.aspx'</script>");
            FillList();
        }
    }
    protected void Btnaddnew_Click(object sender, EventArgs e)
    {
        Response.Redirect("connectiontype.aspx");
    }
    private Boolean FillList()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_connection";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }
}