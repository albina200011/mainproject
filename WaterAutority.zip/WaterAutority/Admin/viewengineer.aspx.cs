﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_viewengineer : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();

    protected void Page_Load(object sender, EventArgs e)
    {

        FillList();
    }
    protected void Btnaddnew_Click(object sender, EventArgs e)
    {
        Response.Redirect("Engineerreg.aspx");
    }
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int engineer_id = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "edt")
        {
            Response.Redirect("Engineerreg.aspx?cid=" + engineer_id);
        }
        else
        {
            objmysqlcommand.CommandText = "delete from tbl_engineer where EngineerId='" + engineer_id + "'";
            objdataaccess.ExecuteQuery(objmysqlcommand);
            Response.Write("<script>alert('Deleted Successfully');window.locationmanager='viewengineer.aspx'</script>");
            FillList();
        }
    }
    private Boolean FillList()
    {
        objmysqlcommand.CommandText = "SELECT EngineerId,t1.EngineerName as EngineerName,t2.OfficeName as EOId FROM tbl_engineer t1,tbl_office t2 where t1.EOId=t2.OfficeId";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }
}