﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_viewoffice : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();

    protected void Page_Load(object sender, EventArgs e)
    {

        FillList();
    }
    protected void Btnaddnew_Click(object sender, EventArgs e)
    {
        Response.Redirect("office.aspx");
    }
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int office_id = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "edt")
        {
            Response.Redirect("office.aspx?cid=" + office_id);
        }
        else
        {
            objmysqlcommand.CommandText = "delete from tbl_office where OfficeId='" + office_id + "'";
            objdataaccess.ExecuteQuery(objmysqlcommand);
            Response.Write("<script>alert('Deleted Successfully');window.locationmanager='viewoffice.aspx'</script>");
            FillList();
        }
    }
    private Boolean FillList()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_office";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }
}