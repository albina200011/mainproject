﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_Application : System.Web.UI.Page
{

    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int application_id;
    string doj = System.DateTime.Now.ToString("yyyy-MM-dd"); 
    protected void Page_Load(object sender, EventArgs e)
    {
        application_id = Convert.ToInt32(Request.QueryString["cid"]);
        if (!IsPostBack)
        {
            Filldistrictdropdown();
            Fillcategorydropdown();

            Filldata();
        }
    }
    public bool insertdata()
    {

        objmysqlcommand.CommandText = "insert into tbl_application(ADId,ALId,AOId,ATypeId,ApplicationName,ApplicationContact,ApplicationAddress,IdProof,ApplicationDate,ACId) " +
                                                                  "values('" + ddldistrict.SelectedValue + "','" + ddllocation.SelectedValue + "','" + ddlofficename.SelectedValue + "','" + txtcategory.Text + "','" + txtname.Text + "','"
                                                                  + txtphonenumber.Text + "','" + txtemail.Text + "','" + txtid.Text + "','" + doj + "','" + Session["CustomerId"].ToString() + "')";
       

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Application details successfully Saved');window.location='CustomerHome.aspx'</script>");
        }

        return true;

    }
    private Boolean Fillcategorydropdown()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_connection ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtcategory.Items.Insert(0, "--SELECT--");
            foreach (DataRow dr in objdatatable.Rows)
            {
                txtcategory.Items.Add(new ListItem(dr["type"].ToString(), dr["TypeId"].ToString()));
            }
        }
        return true;
    }

    private Boolean Filldistrictdropdown()
    {
        objmysqlcommand.CommandText = "select * from tbl_district";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddldistrict.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddldistrict.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddldistrict.Items.Add(new ListItem(category["DistrictName"].ToString(), category["DistrictId"].ToString()));
            }
        }
        return true;
    }

    //private Boolean Fillofficedropdown()
    //{
    //    objmysqlcommand.CommandText = "SELECT * FROM tbl_office ";
    //    objdatatable = objdataaccess.GetRecords(objmysqlcommand);
    //    if (objdatatable.Rows.Count > 0)
    //    {
    //        ddlofficename.Items.Insert(0, "--SELECT--");
    //        foreach (DataRow dr in objdatatable.Rows)
    //        {
    //            ddlofficename.Items.Add(new ListItem(dr["name"].ToString(), dr["office_id"].ToString()));
    //        }
    //    }
    //    return true;
    //}
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_application where ApplicationId=" + application_id;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            ddldistrict.SelectedValue = objdatatable.Rows[0]["ADId"].ToString();
            ddllocation.SelectedValue = objdatatable.Rows[0]["ALId"].ToString();
            ddlofficename.SelectedValue = objdatatable.Rows[0]["AOId"].ToString();
            txtcategory.Text = objdatatable.Rows[0]["ATypeId"].ToString();
            txtname.Text = objdatatable.Rows[0]["ApplicationName"].ToString();
            txtphonenumber.Text = objdatatable.Rows[0]["ApplicationContact"].ToString();
            txtemail.Text = objdatatable.Rows[0]["ApplicationAddress"].ToString();
            txtid.Text = objdatatable.Rows[0]["IdProof"].ToString();
           
        }
        return true;
    }
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_application SET ApplicationName ='" + txtname.Text + "',ApplicationContact='" + txtphonenumber.Text + "',ApplicationAddress ='" + txtemail.Text + "',IdProof ='" + txtid.Text + "' where ApplicationId='" + application_id + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Application details successfully Updated');window.location='Application.aspx'</script>");

        }
        return true;
    }
    private Boolean checkAlreadyExist()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_application where IdProof='" + txtid.Text + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            Response.Write("<script>alert('Email is already exist ');window.location='Application.aspx'</script>");
            return false;
        }
        return true;

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {

        if (Convert.ToInt32(application_id) > 0)
        {
            FnUpdateData();
        }
        else
        {
            if (checkAlreadyExist())
            {
                insertdata();
            }
        }
    }
    public void filllocation()
    {

        objmysqlcommand.CommandText = "select * from tbl_location where DId='" + ddldistrict.SelectedValue + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddllocation.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddllocation.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddllocation.Items.Add(new ListItem(category["LocationName"].ToString(), category["LocationId"].ToString()));
            }
        }
    }
    public void filloffice()
    {

        objmysqlcommand.CommandText = "select * from tbl_office where OLId='" + ddllocation.SelectedValue + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddlofficename.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddlofficename.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddlofficename.Items.Add(new ListItem(category["OfficeName"].ToString(), category["OfficeId"].ToString()));
            }
        }
    }
    protected void ddldistrict_SelectedIndexChanged(object sender, EventArgs e)
    {
        filllocation();
    }

    protected void ddllocation_SelectedIndexChanged(object sender, EventArgs e)
    {
        filloffice();
    }
}