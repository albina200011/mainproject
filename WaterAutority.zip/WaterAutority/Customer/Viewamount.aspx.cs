﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_Viewamount : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int consumer_no=0;
    protected void Page_Load(object sender, EventArgs e)
    {
        consumer_no = Convert.ToInt32(Session["consumer_no"]); 
        if (!IsPostBack)
        {
            FillList();
        }
    }
  
    private Boolean FillList()
    {

        objmysqlcommand.CommandText = "SELECT * FROM tbl_bill WHERE application_id='" + consumer_no + "' and status='Pending'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {

       // Response.Redirect("../Payment/selectpayment.aspx?consumer_id='" + appid + "'");
    }
    
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        int bill_id = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "edt")
        {

            Response.Redirect("../Payment1/selectPayment.aspx?billid=" +bill_id);
        }
    }
}