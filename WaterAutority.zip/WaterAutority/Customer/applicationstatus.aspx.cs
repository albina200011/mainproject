﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_applicationstatus : System.Web.UI.Page
{

    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    String customer_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        FillList();
        chek();
    }
    private Boolean chek()
    {

        objmysqlcommand.CommandText = "SELECT * FROM tbl_application a INNER JOIN tbl_district d INNER JOIN tbl_location l INNER JOIN tbl_office o INNER JOIN tbl_connection t ON a.ADId = d.DistrictId AND a.ALId = l.LocationId AND a.ATypeId = t.TypeId AND a.AOId = o.OfficeId WHERE ACId='" + Session["CustomerId"].ToString() + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {

            String cid = objdatatable.Rows[0]["ApplicationId"].ToString();
            Session["consumer_id"] = cid;
            Session["amount"] = 1020;
            if (objdatatable.Rows[0]["Status"].ToString() == "ACCEPTED")
            {
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[2] { new DataColumn("ACId"), new DataColumn("PayStatus") });
                if (objdatatable.Rows[0]["PayStatus"].ToString() == "Pending")
                {
                    dt.Rows.Add(cid, "Click Here!!");
                }
                else
                {
                    dt.Rows.Add(cid, "</a>Done<a>");
                }
                ListView2.DataSource = dt;
                ListView2.DataBind();


            }
        }
        return true;

    }
    private Boolean FillList()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_application a INNER JOIN tbl_district d INNER JOIN tbl_location l INNER JOIN tbl_office o INNER JOIN tbl_connection t ON a.ADId = d.DistrictId AND a.ALId = l.LocationId AND a.ATypeId = t.TypeId AND a.AOId = o.OfficeId WHERE ACId='" + Session["CustomerId"].ToString() + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {

    }
}