﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_complaints : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int complaint_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        complaint_id = Convert.ToInt32(Request.QueryString["cid"]);
        if (!IsPostBack)
        {
            Filldistrictdropdown();
            Fillcategorydropdown();

            Filldata();
        }
    }
    public bool insertdata()
    {

        objmysqlcommand.CommandText = "insert into tbl_complaint(ComDId,ComLId,ComOId,ComTypeId,Complaint,ComCId) " +
                                          "values('" + ddldistrict.SelectedValue + "','" + ddllocation.SelectedValue + "','" + ddlofficename.SelectedValue + "','" + txtcategory.Text + "','" + txtcomplaint.Text + "','" + Session["CustomerId"].ToString() + "')";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Complaint details successfully Saved');window.location='complaints.aspx'</script>");
        }

        return true;

    }
    private Boolean Fillcategorydropdown()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_connection ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtcategory.Items.Insert(0, "--SELECT--");
            foreach (DataRow dr in objdatatable.Rows)
            {
                txtcategory.Items.Add(new ListItem(dr["type"].ToString(), dr["TypeId"].ToString()));
            }
        }
        return true;
    }

    private Boolean Filldistrictdropdown()
    {
        objmysqlcommand.CommandText = "select * from tbl_district";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddldistrict.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddldistrict.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddldistrict.Items.Add(new ListItem(category["DistrictName"].ToString(), category["DistrictId"].ToString()));
            }
        }
        return true;
    }

    //private Boolean Fillofficedropdown()
    //{
    //    objmysqlcommand.CommandText = "SELECT * FROM tbl_office ";
    //    objdatatable = objdataaccess.GetRecords(objmysqlcommand);
    //    if (objdatatable.Rows.Count > 0)
    //    {
    //        ddlofficename.Items.Insert(0, "--SELECT--");
    //        foreach (DataRow dr in objdatatable.Rows)
    //        {
    //            ddlofficename.Items.Add(new ListItem(dr["name"].ToString(), dr["office_id"].ToString()));
    //        }
    //    }
    //    return true;
    //}
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_complaint where ComplaintId=" + complaint_id;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            ddldistrict.SelectedValue = objdatatable.Rows[0]["ComDId"].ToString();
            ddllocation.SelectedValue = objdatatable.Rows[0]["ComLId"].ToString();
            ddlofficename.SelectedValue = objdatatable.Rows[0]["ComOId"].ToString();
            txtcategory.Text = objdatatable.Rows[0]["ComTypeId"].ToString();
            txtcomplaint.Text = objdatatable.Rows[0]["Complaint"].ToString();
        }
            return true;
        }
    
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_complaint SET Complaint ='" + txtcomplaint.Text + "' where ComplaintId='" + complaint_id + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Application details successfully Updated');window.location='viewengineer.aspx'</script>");

        }
        return true;
    }
   
    public void filllocation()
    {

        objmysqlcommand.CommandText = "select * from tbl_location where DId='" + ddldistrict.SelectedValue + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddllocation.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddllocation.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddllocation.Items.Add(new ListItem(category["LocationName"].ToString(), category["LocationId"].ToString()));
            }
        }
    }
    public void filloffice()
    {

        objmysqlcommand.CommandText = "select * from tbl_office where OLId='" + ddllocation.SelectedValue + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ddlofficename.Items.Clear();
        if (objdatatable != null && objdatatable.Rows.Count > 0)
        {
            ddlofficename.Items.Add(new ListItem("---Select---", "-1"));
            foreach (DataRow category in objdatatable.Rows)
            {
                ddlofficename.Items.Add(new ListItem(category["OfficeName"].ToString(), category["OfficeId"].ToString()));
            }
        }
    }
    protected void ddldistrict_SelectedIndexChanged(object sender, EventArgs e)
    {
        filllocation();
    }

    protected void ddllocation_SelectedIndexChanged(object sender, EventArgs e)
    {
        filloffice();
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        insertdata();
        //if (Convert.ToInt32(complaint_id) > 0)
        //{
           
        //}
    }
}