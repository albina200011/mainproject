﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_complaintstatus : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    String customer_id;

    protected void Page_Load(object sender, EventArgs e)
    {
        FillList();
    }
    private Boolean FillList()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_complaint c INNER JOIN tbl_connection t ON c.ComTypeId = t.TypeId  WHERE ComCId='" + Session["CustomerId"].ToString() + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {

    }
}