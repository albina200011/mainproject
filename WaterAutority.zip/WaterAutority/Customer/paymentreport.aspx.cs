﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Manager_SalesReport : System.Web.UI.Page
{

    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {

        // Session["eoid"] = 2;
        HttpContext.Current.Session["CustomerId"] = Session["CustomerId"];
    }

    [System.Web.Services.WebMethod(EnableSession = true)]
    public static List<Names> GetList(string fdate, string tdate)
    {


        List<Names> names = new List<Names>();
        MySqlCommand objmysqlcommand = new MySqlCommand();
        DataAccess objdataaccess = new DataAccess();
        DataTable objdatatable = new DataTable();


        objmysqlcommand.CommandText = "select * from tbl_payment p inner  tbl_bill b on p.PaidAmount = b.amount where PaidDate>='" + fdate + "' and PaidDate<='" + tdate + "' and AOId='" + HttpContext.Current.Session["CustomerId"] + "'    ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        foreach (DataRow dr in objdatatable.Rows)
        {
            names.Add(new Names(int.Parse(dr["payment_id"].ToString()), dr["PaidDate"].ToString(), int.Parse(dr["PaidAmount"].ToString())));
        }

        return names;




    }
    public class Names
    {
        public int paymentid;

        public string paiddate;
        public int amt;


        public Names(int payment_id, string paid_date, int amount)
        {
            paymentid = payment_id;

            paiddate = Convert.ToDateTime(paid_date).ToString("dd-MM-yyyy");
            amt = amount;
        }
    }
    protected void Btnaddnew_Click(object sender, EventArgs e)
    {

        objmysqlcommand.CommandText = "select * from tbl_payment p inner  tbl_bill b ON p.PaidAmount = b.amount where PaidDate>='" + txtfromdate.Text + "' and PaidDate<='" + txttodate.Text + "' and AOId='" + HttpContext.Current.Session["CustomerId"] + "'    ";


        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            CreateExcelFile(objdatatable);
        }
    }

    public void CreateExcelFile(DataTable Excel)
    {
        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=Applicationreport.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {

            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {

                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";

            }

            Response.Write("\n");


        }
        Response.End();
    }
}