﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_reportpaymenthistory : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int catid;

    protected void Page_Load(object sender, EventArgs e)
    {
        FillList();

    }
    private Boolean FillList()
    {
        objmysqlcommand.CommandText = "SELECT * From tbl_payment p INNER JOIN tbl_bill b ON p.PaidAmount = b.amount Where PCId='" + Session["CustomerId"].ToString() + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView2.DataSource = objdatatable;
        ListView2.DataBind();
        return true;
    }

    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        FillList();
    }


    protected void btnexport_Click(object sender, EventArgs e)
    {
        objmysqlcommand.CommandText = "SELECT * From tbl_payment p INNER JOIN tbl_bill b ON p.PaidAmount = b.amount Where PCId='" + Session["CustomerId"].ToString() + "'";

        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            CreateExcelFile(objdatatable);
        }
    }
    public void CreateExcelFile(DataTable Excel)
    {
        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=PaymentHistoryDetails.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {

            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {

                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";

            }

            Response.Write("\n");


        }
        Response.End();
    }

}
