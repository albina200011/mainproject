﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_resetcustomerpassword : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int customer_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        customer_id = Convert.ToInt16(Session["CustomerId"]);
    }
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_customer SET CPassword ='" + txtrenewpassword.Text + "' where CustomerId='" + Session["CustomerId"] + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "key", "alert('Brand details successfully Updated');", true);
            Response.Write("<script>alert('Password Updated successfully Saved');window.location='CustomerHome.aspx'</script>");
        }
        return true;
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        FnUpdateData();
    }
}