﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_viewbill : System.Web.UI.Page
{


    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int application_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {

            Filldata();
        }
    }
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_application where ACId=  '" + Session["CustomerId"] + "' ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
           
            txtnumber.Text = objdatatable.Rows[0]["ApplicationId"].ToString();
            txtname.Text = objdatatable.Rows[0]["ApplicationName"].ToString();

            
        }
        return true;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
       int appid=Convert.ToInt32(txtnumber.Text);
       Session["consumer_no"] = appid;
       Response.Redirect("Viewamount.aspx");
    }
}