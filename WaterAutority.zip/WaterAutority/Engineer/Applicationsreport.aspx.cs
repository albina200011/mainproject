﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Manager_SalesReport : System.Web.UI.Page
{

    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {

       // Session["eoid"] = 2;
        HttpContext.Current.Session["eoid"] = Session["eoid"]; 
    }

    [System.Web.Services.WebMethod(EnableSession = true)]
    public static List<Names> GetList(string fdate,string tdate)
    {


        List<Names> names = new List<Names>();
        MySqlCommand objmysqlcommand = new MySqlCommand();
        DataAccess objdataaccess = new DataAccess();
        DataTable objdatatable = new DataTable();


        objmysqlcommand.CommandText = "select * from tbl_application a inner join tbl_engineer e on a.AOId=e.EOId where Status='ACCEPTED' and a.ApplicationDate>='" + fdate + "' and a.ApplicationDate<='" + tdate + "' and AOId='" + HttpContext.Current.Session["eoid"] + "'  ";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        foreach (DataRow dr in objdatatable.Rows)
        {
            names.Add(new Names(int.Parse(dr["ApplicationId"].ToString()), dr["ApplicationName"].ToString(), dr["ApplicationAddress"].ToString(), dr["ApplicationContact"].ToString(), dr["ApplicationDate"].ToString()));
        }

        return names;




    }
    public class Names
    {
        public string applicantname;
        public int applicationid;
        public string applicantaddress;
        public string applicantcontact;
        public string applicationdate;

       
        public Names(int application_id, string applicant_name, string applicant_address, string applicant_contact, string application_date)
        {
            applicationid = application_id;
            applicantname = applicant_name;
            applicantaddress = applicant_address;
            applicantcontact = applicant_contact;
            applicationdate = Convert.ToDateTime(application_date).ToString("dd-MM-yyyy");
        }
    }
    protected void Btnaddnew_Click(object sender, EventArgs e)
    {

        objmysqlcommand.CommandText = "select * from tbl_application a inner join tbl_engineer e on a.AOId=e.EOId where Status='ACCEPTED' and a.ApplicationDate>='" + txtfromdate.Text + "' and a.ApplicationDate<='" + txttodate.Text + "' and AOId='" + HttpContext.Current.Session["eoid"] + "'  ";
       
        
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            CreateExcelFile(objdatatable);
        }
    }

    public void CreateExcelFile(DataTable Excel)
    {
        //Clears all content output from the buffer stream.  
        Response.ClearContent();
        //Adds HTTP header to the output stream  
        Response.AddHeader("content-disposition", string.Format("attachment; filename=Applicationreport.xls"));

        // Gets or sets the HTTP MIME type of the output stream  
        Response.ContentType = "application/vnd.ms-excel";
        string space = "";

        foreach (DataColumn dcolumn in Excel.Columns)
        {

            Response.Write(space + dcolumn.ColumnName);
            space = "\t";
        }
        Response.Write("\n");
        int countcolumn;
        foreach (DataRow dr in Excel.Rows)
        {
            space = "";
            for (countcolumn = 0; countcolumn < Excel.Columns.Count; countcolumn++)
            {

                Response.Write(space + dr[countcolumn].ToString());
                space = "\t";

            }

            Response.Write("\n");


        }
        Response.End();
    }
}