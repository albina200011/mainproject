﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Engineer_billpay : System.Web.UI.Page
{

    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    DataTable objdatatable1 = new DataTable();
    MySqlCommand objmysqlcommand1 = new MySqlCommand();
    int application_id;
    int bill_id;
    int current_reading, previous_reading, actual_reading;
    int type;
    int amount;
    int total;
    protected void Page_Load(object sender, EventArgs e)
    {
        application_id = Convert.ToInt32(Request.QueryString["cid"]);
        if (!IsPostBack)
        {
            Filldata();
        }
    }
    public bool insertdata()
    {
        objmysqlcommand.CommandText = "insert into tbl_bill(application_id,previous_reading,current_reading,amount,from_date,to_date,due_date,status) values('" + txtnumber.Text + "','" + txtprev.Text + "','" + txtread.Text + "','" + txtamount.Text + "','" + txtfrom.Text + "','" + txttod.Text + "','" + txtpayd.Text + "','Pending')";
        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Bill Details Registered successfully Saved');window.location='billpay.aspx'</script>");
        }

        return true;

    }
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_application where ApplicationId=" + application_id;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtnumber.Text = objdatatable.Rows[0]["ApplicationId"].ToString();
            txtname.Text = objdatatable.Rows[0]["ApplicationName"].ToString();
            txtphonenumber.Text = objdatatable.Rows[0]["ApplicationContact"].ToString();
        }
        return true;
    }
    private Boolean Fillvalue()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_bill where bill_id=" + bill_id;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtprev.Text = objdatatable.Rows[0]["previous_reading"].ToString();
            txtread.Text = objdatatable.Rows[0]["current_reading"].ToString();
            txtamount.Text = objdatatable.Rows[0]["amount"].ToString();
            txtfrom.Text = objdatatable.Rows[0]["from_date"].ToString();
            txttod.Text = objdatatable.Rows[0]["to_date"].ToString();
            txtpayd.Text = objdatatable.Rows[0]["due_date"].ToString();
        }
        return true;
    }
    protected void btnSave_Click2(object sender, EventArgs e)
    {
        current_reading = Convert.ToInt32(txtread.Text);
        previous_reading = Convert.ToInt32(txtprev.Text);
        actual_reading = current_reading - previous_reading;
        txtactual.Text = actual_reading.ToString();
        objmysqlcommand.CommandText = "SELECT * FROM tbl_application where ApplicationId='" + application_id + "'";

        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            type = Convert.ToInt32(objdatatable.Rows[0]["ATypeId"].ToString());
            objmysqlcommand1.CommandText = "SELECT * FROM tbl_tariff where TTId='" + type + "'";
            objdatatable1 = objdataaccess.GetRecords(objmysqlcommand1);
            if (objdatatable1.Rows.Count > 0)
            {
                amount = Convert.ToInt32(objdatatable1.Rows[0]["Amount"]);
                total = actual_reading * amount;
                txtamount.Text = total.ToString();
            }

        }
    }
    
    protected void Button1_Click(object sender, EventArgs e)
    {
        insertdata();

    }



   
    
}