﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_resetcustomerpassword : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int engineer_id;
    protected void Page_Load(object sender, EventArgs e)
    {
        engineer_id = Convert.ToInt16(Session["engineer_id"]);
    }
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_engineer SET EngPassword ='" + txtrenewpassword.Text + "' where EngineerId='" + Session["engineer_id"] + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "key", "alert('Brand details successfully Updated');", true);
            Response.Write("<script>alert('Password Updated successfully Saved');window.location='EngineerHome.aspx'</script>");
        }
        return true;
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        FnUpdateData();
    }
}