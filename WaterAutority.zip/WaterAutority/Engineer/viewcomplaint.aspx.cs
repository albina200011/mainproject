﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Engineer_viewcomplaint : System.Web.UI.Page
{

    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        FillList();
    }
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        if (e.CommandName == "accept")
        {
            int complaint_id = Convert.ToInt32(e.CommandArgument);
            objmysqlcommand.CommandText = "UPDATE tbl_complaint SET CStatus ='" + "ACTION INITIATED" + "' where ComplaintId='" + complaint_id + "'";
            if (objdataaccess.ExecuteQuery(objmysqlcommand))
            {
                Response.Write("<script>alert('Complaint Accepted Successfully!!!');window.location='viewcomplaint.aspx'</script>");
            }
        }
        else
        {
            int complaint_id = Convert.ToInt32(e.CommandArgument);
            objmysqlcommand.CommandText = "UPDATE tbl_complaint SET CStatus ='" + "REJECTED" + "' where ComplaintId='" + complaint_id + "'";
            if (objdataaccess.ExecuteQuery(objmysqlcommand))
            {
                Response.Write("<script>alert('Complaint Rejected Successfully!!!');window.location='viewcomplaint.aspx'</script>");
            }
        }
    }
    private Boolean FillList()
    {
        int district_id = Convert.ToInt32(Session["districtid"]);
        objmysqlcommand.CommandText = "SELECT * FROM tbl_complaint c INNER JOIN tbl_district d INNER JOIN tbl_location l  INNER JOIN tbl_office o INNER JOIN tbl_connection t ON c.ComDId = d.DistrictId AND c.ComLId = l.LocationId AND c.ComTypeId = t.TypeId AND c.ComOId = o.OfficeId  WHERE CStatus='Pending' AND o.ODId='" + district_id + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }
}