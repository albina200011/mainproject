﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Engineer_viewpayment : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        FillList();
    }
    protected void ListView1_ItemCommand(object sender, ListViewCommandEventArgs e)
    {
        
    }
    private Boolean FillList()
    {
        int district_id = Convert.ToInt32(Session["districtid"]);
        objmysqlcommand.CommandText = "SELECT * FROM tbl_application a INNER JOIN tbl_district d INNER JOIN tbl_location l INNER JOIN tbl_office o INNER JOIN tbl_connection t ON a.ADId = d.DistrictId AND a.ALId = l.LocationId AND a.ATypeId = t.TypeId AND a.AOId = o.OfficeId WHERE PayStatus='Pending' AND o.ODId='" + district_id + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        ListView1.DataSource = objdatatable;
        ListView1.DataBind();
        return true;
    }
}