﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Guest_customerlogin : System.Web.UI.Page
{

    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    String customerid;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (!isuser())
        {
            Response.Write("<script>alert('Invalid User name or Password!!!');window.location='customerlogin.aspx'</script>");
        }
    }
    protected bool isuser()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_customer where Email='" + Customer_Email.Text + "' and CPassword='" + Customer_Password.Text + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            customerid = objdatatable.Rows[0]["CustomerId"].ToString();
            Session["CustomerId"] = customerid;
            Response.Write("<script>window.location='../Customer/CustomerHome.aspx'</script>");
            return true;
        }
        else
        {
            return false;
        }
    }
}