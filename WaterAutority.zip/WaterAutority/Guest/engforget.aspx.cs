﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Net;
using System.Net.Mail;
using MySql.Data.MySqlClient;

public partial class Guest_custforget : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ButPwd_Click(object sender, EventArgs e)
    {
        objmysqlcommand.CommandText = "select EngineerEmail,EngineerName, EngPassword from tbl_engineer where EngineerEmail='" + txtemail.Text + "'";
        objdataaccess.ExecuteQuery(objmysqlcommand);
        DataTable dt = objdataaccess.GetRecords(objmysqlcommand);

        if (dt.Rows.Count > 0)
        {
            string username = dt.Rows[0]["EngineerEmail"].ToString();
            string password = dt.Rows[0]["EngPassword"].ToString();
            string name = dt.Rows[0]["EngineerName"].ToString();

            MailMessage mm = new MailMessage("projectrecoverymail@gmail.com", txtemail.Text);
            mm.Subject = "Forget Password";
            mm.Body = string.Format("Hello:<h2>{0}</h2>,</br> <h4>{1}</h4> is your Email Id </br></br>  your password is <h4>{2}</h4>",name, username, password);
            mm.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential("projectrecoverymail@gmail.com", "recoverymai");
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;
            smtp.Send(mm);
            Labmsg.Text = "Your Password is sent to " + txtemail.Text;
            Labmsg.ForeColor = Color.Green;


        }
        else
        {
            Labmsg.Text = txtemail.Text + " Thsi email is not exist in our database";
            Labmsg.ForeColor = Color.Red;
        }



    }
}