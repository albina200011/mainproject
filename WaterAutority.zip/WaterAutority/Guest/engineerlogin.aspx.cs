﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Engineer_engineerlogin : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    String engineerid;
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        if (!isuser())
        {
            Response.Write("<script>alert('Invalid User name or Password!!!');window.location='engineerlogin.aspx'</script>");
        }
    }
    protected bool isuser()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_engineer where EngineerEmail='" + Customer_Email.Text + "' and EngPassword='" + Customer_Password.Text + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            engineerid = objdatatable.Rows[0]["EngineerId"].ToString();
            Session["engineer_id"] = engineerid;
            Session["eoid"] = objdatatable.Rows[0]["EOId"];
            Session["districtid"] = objdatatable.Rows[0]["EDId"].ToString(); ;
            Response.Write("<script>window.location='../Engineer/EngineerHome.aspx'</script>");

            return true;
        }
        else
        {
            return false;
        }
    }
}
    