﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;

public partial class Guest_frmAdminLogin : System.Web.UI.Page
{
    DataAccess objdataacess = new DataAccess();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    DataTable objdatatable = new DataTable();
    

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    private Boolean fnLogin()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbladminlogin WHERE adminusername='" + txtusername.Text + "' AND adminpassword='" + txtpassword.Text + "'";
        objdatatable = objdataacess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            Response.Redirect("../Admin/Dashboard.aspx");

        }
        else
        {
            Response.Write("<script>alert('Invalid Username or Password!!!');</script>");

        }

        return true;
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        fnLogin();
    }
}