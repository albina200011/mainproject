﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using MySql.Data.MySqlClient;
using System.Net.Mail;
using System.Net;

public partial class guest_Customer : System.Web.UI.Page
{
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    int customerid;
    string doj = System.DateTime.Now.ToString("yyyy-MM-dd");
    protected void Page_Load(object sender, EventArgs e)
    {
        customerid = Convert.ToInt32(Request.QueryString["cid"]);
       
        if (!IsPostBack)
        {
            //Filldata();
            txtdob.Attributes["max"] = System.DateTime.Now.ToString("yyyy-MM-dd");
            
        }
    }
    public bool insertdata()
    {
       
        objmysqlcommand.CommandText = "insert into tbl_customer(CustomerName,HouseName,DateOfBirth,DateOfOrder, " +
                                          "Gender,Place,Contact,Email,CPassword) " +
                                          "values('" + txtcustomername.Text + "','" + txtHousename.Text + "', '" + txtdob.Text + "', " +
                                          "'" + doj + "','" + rdbgender.SelectedValue + "','" + txtplace.Text + "', " +
                                          "'" + txtphonenumber.Text + "','" + txtemail.Text + "','" + txtpasswd.Text + "')";
            if (objdataaccess.ExecuteQuery(objmysqlcommand))
            {
               
    
                Response.Write("<script>alert('Customer details successfully Saved');window.location='../Guest/GuestHome.aspx'</script>");
            }

        return true;

    }
    private Boolean Filldata()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_customer where CustomerId=" + customerid;
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            txtcustomername.Text = objdatatable.Rows[0]["CustomerName"].ToString();
            txtHousename.Text = objdatatable.Rows[0]["HouseName"].ToString();
            txtdob.Text = objdatatable.Rows[0]["DateOfBirth"].ToString();
            DateTime doj = Convert.ToDateTime(objdatatable.Rows[0]["DateOfOrder"].ToString());
            rdbgender.Text = objdatatable.Rows[0]["Gender"].ToString();
            txtplace.Text = objdatatable.Rows[0]["Place"].ToString();
            txtphonenumber.Text = objdatatable.Rows[0]["Contact"].ToString();
            txtemail.Text = objdatatable.Rows[0]["Email"].ToString();
            
            //txtpasswd.Visible = false;
           // d1.Visible = false;
            Btncancel.Visible = false;
        }
        return true;
    }
   
    private Boolean FnUpdateData()
    {
        objmysqlcommand.CommandText = "UPDATE tbl_customer SET CustomerName ='" + txtcustomername.Text + "',HouseName='" + txtHousename.Text + "',DateOfBirth='" + txtdob.Text + "',Gender='" + rdbgender.Text + "',Contact='" + txtphonenumber.Text + "',Email ='" + txtemail.Text + "' where CustomerId='" + customerid + "'";

        if (objdataaccess.ExecuteQuery(objmysqlcommand))
        {
            Response.Write("<script>alert('Customer  details successfully Updated');window.location='../Customer/frmViewCustomer.aspx'</script>");
            
        }
        return true;
    }
    private Boolean checkAlreadyExist()
    {
        objmysqlcommand.CommandText = "SELECT * FROM tbl_customer where Email='" + txtemail.Text + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            Response.Write("<script>alert('Customer is already exist with same name or email');window.location='frmCustomerReg.aspx'</script>");
            return false;
        }
        return true;

    }
    protected void btnsave_Click1(object sender, EventArgs e)
    {
        if (Convert.ToInt32(customerid) > 0)
        {
            FnUpdateData();
        }
        else
        {
            if (checkAlreadyExist())
            {
                insertdata();
            }
        }
    }
}