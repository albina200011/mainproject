﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PaymentMasterPage : System.Web.UI.MasterPage
{
    int total;
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        int user_id = Convert.ToInt32(Session["CustomerId"].ToString());
         string current_date = DateTime.Now.ToString("yyyy-MM-dd");
        int order_id = Convert.ToInt32(Session["Consumer_Id"]);
        total = Convert.ToInt32(Session["amount"]);
        Session["total"] = total;

        if (!IsPostBack)
        {
            fill();
            trans_id.InnerText = "Transaction ID : PBTID857419";

        }


    }
    public void fill()
    {
      
        
        
            trans_amount.InnerText = "Rs " + total.ToString();

        }
    
}
