﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Payment_creditCard : System.Web.UI.Page
{
    int total;
    int user_id;
    int order_id;
    string current_date;
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        user_id = Convert.ToInt32(Session["CustomerId"].ToString());
        current_date = DateTime.Now.ToString("yyyy-MM-dd");
        order_id = Convert.ToInt32(Session["Consumer_Id"]);
        total = Convert.ToInt32(Session["amount"]);
        Session["total"] = total;

    }
    protected void btn_Payment_Click(object sender, EventArgs e)
    {
        objmysqlcommand.CommandText = "insert into tbl_payment(PCId,ConsumerId,PaidAmount,PaidDate)values('" + user_id + "','" + order_id + "','" + total + "','" + current_date + "')";
        objdataaccess.ExecuteQuery(objmysqlcommand);
        objmysqlcommand.CommandText = "UPDATE tbl_application SET PayStatus='Done' WHERE ApplicationId='" + order_id + "'";
        objdataaccess.ExecuteQuery(objmysqlcommand);
        ScriptManager.RegisterStartupScript(this, this.GetType(), "key", "alert('Payment Done successfully');window.location='../Customer/CustomerHome.aspx'", true);
    }
    
}