﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PaymentMasterPage : System.Web.UI.MasterPage
{
    int bill;
    DataAccess objdataaccess = new DataAccess();
    DataTable objdatatable = new DataTable();
    MySqlCommand objmysqlcommand = new MySqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        //int user_id = Convert.ToInt32(Session["customer_id"].ToString());
        // string current_date = DateTime.Now.ToString("yyyy-MM-dd");
        //int order_id = Convert.ToInt32(Session["Consumer_Id"]);
        //total = Convert.ToInt32(Session["amount"]);
        //Session["total"] = total;
        bill = Convert.ToInt32(Request.QueryString["billid"]);
       
        if (!IsPostBack)
        {
            fill();
            trans_id.InnerText = "Transaction ID : PBTID857419";

        }


    }
    public void fill()
    {

        objmysqlcommand.CommandText = "SELECT * FROM tbl_bill WHERE bill_id='" + bill + "'";
        objdatatable = objdataaccess.GetRecords(objmysqlcommand);
        if (objdatatable.Rows.Count > 0)
        {
            int total = Convert.ToInt32(objdatatable.Rows[0]["amount"]);
            
            int consumerno = Convert.ToInt32(objdatatable.Rows[0]["application_id"]);
            trans_amount.InnerText = "Rs" + total;
            Session["amount"] = total;
            
            Session["applid"] = consumerno;
            Session["billid"] = Convert.ToInt32(objdatatable.Rows[0]["bill_id"]); 
        }

        }
    
}
